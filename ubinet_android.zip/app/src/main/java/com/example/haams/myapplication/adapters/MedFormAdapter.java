package com.example.haams.myapplication.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;

import com.example.haams.myapplication.R;
import com.example.haams.myapplication.data.MedForm;
import com.example.haams.myapplication.listener.ButtonClickListener;

import java.util.ArrayList;

/**
 * Created by haams on 2017-08-06.
 */

public class MedFormAdapter extends BaseAdapter implements View.OnClickListener {
    private ArrayList<MedForm> medFormList;
    private Context context;
    private int hours[];
    private int minutes[];
    private final String TAG = "MedFormAdapter";


    public MedFormAdapter(ArrayList<MedForm> medFormList, Context context) {
        this.medFormList = medFormList;
        this.context = context;
    }

    public MedFormAdapter(ArrayList<MedForm> medFormList, Context context, int[] hours, int[] minutes) {
        this.medFormList = medFormList;
        this.context = context;
        this.hours = hours;
        this.minutes = minutes;
        hours = new int[3];
        minutes = new int[3];
    }

    @Override
    public int getCount() {
        return medFormList.size();
    }

    @Override
    public Object getItem(int position) {
        return medFormList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    class Holder {
        EditText medListEdt;
        Button btnSetAlarm;
        Button btnSetDate;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View itemView = null;
        if (convertView == null)
            itemView = LayoutInflater.from(context).inflate(R.layout.activity_med_form_list_items, parent, false);

        Holder holder = new Holder();
        holder.medListEdt = (EditText) itemView.findViewById(R.id.medListEdt);
        holder.btnSetAlarm = (Button) itemView.findViewById(R.id.btnSetAlarm);
        holder.btnSetDate = (Button) itemView.findViewById(R.id.btnSetDate);

        /*
        뷰가지고 와서 이걸 서버에 넘겨야 한다.
        여기서 작업을 해야함
         */
//
//        holder.btnSetAlarm.setOnClickListener(new ButtonClickListener(context,medFormList,position));
//        holder.btnSetDate.setOnClickListener(new ButtonClickListener(context,medFormList,position));


        holder.btnSetAlarm.setOnClickListener(this);
        holder.btnSetDate.setOnClickListener(this);

        return itemView;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSetAlarm:
                setAlarmBox();
                break;
            case R.id.btnSetDate:

                break;
        }
    }

    private void setAlarmBox() {
        final AlertDialog.Builder alarmBox = new AlertDialog.Builder(context);
        final View alarmView = LayoutInflater.from(context).inflate(R.layout.activity_med_form1, null);
        alarmBox.setView(alarmView); // 알람 설정
        final TimePicker timePicker = (TimePicker) alarmView.findViewById(R.id.medTimePicker);
        alarmBox.setTitle("투약 알림 시간 설정");
        alarmBox.setMessage("세 차례 알림 설정 해주세요");
        alarmBox.setPositiveButton("설정완료", new AlarmListener(timePicker));

        alarmBox.show();

    }

    private class AlarmListener implements DialogInterface.OnClickListener {
        private TimePicker timePicker;

        public AlarmListener(TimePicker timePicker) {
            this.timePicker = timePicker;
        }

        @Override
        public void onClick(DialogInterface dialog, int which) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                int hour = timePicker.getHour();
                int minute = timePicker.getMinute();
                setAlarmTime(hour, minute);
            }
            dialog.dismiss();
        }
    }

    private void setAlarmTime(int hour, int minute) {
        Log.i(TAG, hour + ":" + minute);
    }
}
