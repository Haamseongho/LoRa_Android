package com.example.haams.myapplication.sub_activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.haams.myapplication.R;

public class MapActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
    }
}
