package com.example.haams.myapplication.sub_activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.example.haams.myapplication.R;
import com.example.haams.myapplication.adapters.MedFormAdapter;
import com.example.haams.myapplication.data.MedForm;

import java.util.ArrayList;

public class MedFormActivity extends AppCompatActivity {

    private ListView medList;
    private MedFormAdapter medFormAdapter;
    private ArrayList<MedForm> medFormList;
    private int hours[];
    private int minutes[];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medform);

        initViews();
    }

    private void initViews() {
        medList = (ListView)findViewById(R.id.medListView);
        medFormList = new ArrayList<>();
        hours = new int[]{9,15,22};
        minutes = new int[]{30,30,30};
        /*
        기본 예제만 추가 // 이 부분 서버를 연결해서 데이터 넣는거 해줘야함.
         */
        medFormList.add(new MedForm("약 이름1",hours,minutes));
        medFormAdapter = new MedFormAdapter(medFormList,this);
        medList.setAdapter(medFormAdapter);
    }
}
